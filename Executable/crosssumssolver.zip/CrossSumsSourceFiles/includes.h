#ifndef INCLUDES_H
#define INCLUDES_H
//frequently used includes

#include <QtGui/QApplication>
#include <fstream>
#include <iostream>
#include <istream>
#include <ostream>
#include <string>
#include <stdlib.h>
#include <QColor>
#include <QDebug>
#include <QFont>
#include <QProcess>
#include "headinput.h"
#include "invalidinput.h"
#include "crosssumvalue.h"
#include "crosssumhead.h"
#include "crosssumpuzzle.h"
#include "crosssumsui.h"

#include <QDebug>

#endif // INCLUDES_H
